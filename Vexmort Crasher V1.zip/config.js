global.owner = ['6285876670135'] // owner number
global.connect = true // Ubah ke false jika ingin mengkoneksikan bot menggunakan QrCode
global.url = "https://t.me/AlwaysMunnn"
global.url2 = "https://t.me/AlwaysMunnn"
global.packname = "🕊𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿🕊"
global.author = "AlwaysMunnn"